import NewComponent from './NewComponent';
interface Props {
    state: number,
    handleChange: () => void,
    name: string
}
function HoverCounter(props: Props) {
    const { state, handleChange, name } = props;
    return (
        <div>
            <div>{name}</div>
            <button onMouseOver={handleChange}>
                Increment
            </button>
            <p>
                Clicked: {state}
            </p>
        </div>
    );
}
export default NewComponent(HoverCounter);