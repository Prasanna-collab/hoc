// const newComponent = higherFunction(WrappedComponent);

import { useState } from "react"

// newComponent => Will be the enhanced component
// higherFunction => Will be the higher order function used to enhace the original component
// BaseComponent => Will be the original component, (whose fucntionality we  want to extend.)

//Common HOC problem: Passing down props to specific components

const NewComponent = (BaseComponent: any, incrementSize?: number) => {
  return function EnhancedComponent(props: any) {
    const [state, setState] = useState(0);
    const handleChange = (incrementSize: number) => {
      setState(prev => prev + incrementSize)
    }
    return <BaseComponent {...props} state={state} handleChange={() => handleChange(incrementSize ? incrementSize : 1)} />
  }
}

export default NewComponent