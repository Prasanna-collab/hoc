import NewComponent from "./NewComponent";

const ClickCounter = (props: any) => {
    console.log(props)
    const { state, handleChange, name } = props;
    console.log(state);
    return (
        <div>
           <div>{name}</div> 
            <button onClick={handleChange}>Increment</button>
            <p>Clicked: {state}</p> 
        </div>
    )
}

export default NewComponent(ClickCounter,3);