import ClickCounter from './Components/ClickCounter'
import HoverCounter from './Components/HoverCounter'

const App = () => {
  return (
    <div className='App'>
      <h1>Higher Order Component</h1>
      {/* Even though code samples are valid in this case, this is  a major problem
      1. Both files posses similiar code logic.
      2. This breaks the DRY concept. (Dont Repeat Yourself) */}
      {/* 3. This is where Higher-order components comes in 
      4.  Higher-order components allow developers to reuse code logic in their projects
      */}
      {/* A higher order component is a component that takes another
       component as an argument and returns a new refactored component */}
      <ClickCounter name={`Click Counter`} />
      <HoverCounter name={`Hover Counter`} />
    </div>
  )
}

export default App